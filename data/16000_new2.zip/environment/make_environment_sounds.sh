counter=1
for FILE in ../cough_16000_new/*; 
do 
    arecord -f dat -d 2 -c 1 -r 16000 "$counter.wav"
    # ffmpeg -i "$FILE" -vn "../public_dataset_wav/$counter.wav"
    counter=$((counter+1))
    echo $FILE; 
done